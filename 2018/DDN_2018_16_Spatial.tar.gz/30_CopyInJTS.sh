#!/usr/bin/bash


echo ""
echo ""
echo "Certain DSE Search geo-spatial routines (polygon, other) require the Apache Solr"
echo "JTS libraries. (JTS: Java Topology Suite)"
echo ""
echo "This program will check to see if these libraries were already installed. If these"
echo "libraries were not already installed, this program will do so now."
echo ""

[ -f /opt/dse/node1/resources/solr/lib/jts*.jar ] && {

   echo "RESULT: The JTS libraries were already installed."
   echo ""
   echo ""

} || {

   echo "RESULT: The JTS libraries were NOT already installed."
   echo ""
   echo ""
   echo "Installing JTS libraries .."
   cp "80 Software"/*.jar /opt/dse/node1/resources/solr/lib
   echo ""
   echo "RESULT: The JTS libraries are now installed."
   echo ""
   echo ""
   echo "WARNING: If you have previously booted DSE, you should reboot now in order"
   echo "that these changes may take effect."
   echo ""
   echo ""

}









