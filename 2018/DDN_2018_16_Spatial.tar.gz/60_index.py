



#############################################################
## Imports ##################################################


#
#  Flask is our Python based Web server.
#
from flask import Flask, render_template, request, jsonify

#
#  This import allows us to use a directory other than the
#  default for Flask CSS files and related.
#
import os, json

#
#  Connectivity to DataStax Enterprise / Cassandra
#
from dse.cluster import Cluster

#
#  Generate a unique key value
#
import uuid


   

#############################################################
## Inits, Opens, and Sets ###################################


#
#  Instantiate flask object
#
m_app = Flask(__name__)


#  
#  Set flask defaults for locating files
#
m_templateDir = os.path.abspath("45_views" )
m_staticDir   = os.path.abspath("44_static")
   #
m_app.template_folder = m_templateDir
m_app.static_folder   = m_staticDir


#
#  Assuming a DSE at localhost with DSE Search turned on
#
l_cluster = Cluster(
   contact_points=['127.0.0.1']
   )
m_session = l_cluster.connect()




#############################################################
## Our Web pages (page handlers) ############################


#
#  This is our main page.
#
#  This ia a single page Web app; after this page loads,
#  everything else is just data/AJAX.
#
@m_app.route('/')
def overview_tab():
   return render_template("60_Index.html")


      ###############################################


#
#  Run the first query screen, TAB 1.
#
@m_app.route('/_do_geoQuery1')
def do_geoQuery1():
   global m_session

   #
   #  Parameters sent from client to server.
   #
   l_lat    = request.args.get('h_lat'  )
   l_lng    = request.args.get('h_lng'  )
      #
   l_latlng = l_lat + "," + l_lng 
   #
   #  Taking only the first word in name. Could do multiple
   #  words, didn't want to write the code.
   #
   l_name1  = request.args.get('h_name' )
   l_name2  = l_name1.split(' ', 1)[0]
      #
   l_dist   = request.args.get('h_dist' )
   l_qtype  = request.args.get('h_qtype')

   #
   #  Variable we send back to the client; points on the map.
   #
   l_markers = []
      
   #
   #  Building the query string.
   #
   #  True if we are also to look for the name of a (business)
   #  in addition to a coordinate point.
   #
   if (len(l_name2) > 0):
      if (l_qtype == "round"):
         #
         #  Radius query.
         #
         l_stmt =                                              \
            "SELECT md_lat, md_lng, md_name, md_mysource,  " + \
            "md_phone                                      " + \
            "FROM ks_16.my_mapdata                         " + \
            "WHERE solr_query =                            " + \
            "'{ \"q\" : \"md_name:" + l_name2 + "\", "       + \
            "\"fq\" :                                      " + \
            "\"{!geofilt pt="                                + \
            l_latlng  + " "                                  + \
            "sfield=md_latlng d="                            + \
            l_dist                                           + \
            "}\" }' LIMIT 1000;                              "
      else:
         #
         #  Bounding box query.
         #
         l_stmt =                                              \
            "SELECT md_lat, md_lng, md_name, md_mysource,  " + \
            "md_phone                                      " + \
            "FROM ks_16.my_mapdata                         " + \
            "WHERE solr_query =                            " + \
            "'{ \"q\" : \"md_name:" + l_name2 + "\", "       + \
            "\"fq\" :                                      " + \
            "\"{!bbox pt="                                   + \
            l_latlng  + " "                                  + \
            "sfield=md_latlng d="                            + \
            l_dist                                           + \
            "}\" }' LIMIT 1000;                              "
   #
   #  No name of (business) was sent; just query a point.
   #
   else:
      if (l_qtype == "round"):
         #
         #  Radius query.
         #
         l_stmt =                                              \
            "SELECT md_lat, md_lng, md_name, md_mysource,  " + \
            "md_phone                                      " + \
            "FROM ks_16.my_mapdata                         " + \
            "WHERE solr_query =                            " + \
            "'{ \"q\" : \"*:*\", \"fq\" :                  " + \
            "\"{!geofilt pt="                                + \
            l_latlng  + " "                                  + \
            "sfield=md_latlng d="                            + \
            l_dist                                           + \
            "}\" }' LIMIT 1000;                              "
      else:
         #
         #  Bounding box query.
         #
         l_stmt =                                              \
            "SELECT md_lat, md_lng, md_name, md_mysource,  " + \
            "md_phone                                      " + \
            "FROM ks_16.my_mapdata                         " + \
            "WHERE solr_query =                            " + \
            "'{ \"q\" : \"*:*\", \"fq\" :                  " + \
            "\"{!bbox pt="                                   + \
            l_latlng  + " "                                  + \
            "sfield=md_latlng d="                            + \
            l_dist                                           + \
            "}\" }' LIMIT 1000;                              "
               #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Query1: " + l_stmt2

   l_rows = m_session.execute(l_stmt)
   l_cntr = 0
      
   #
   #  Fetch loop, build a return variable to the client.
   #
   for l_row in l_rows:
      l_cntr += 1 
         #
      ql_lat    = float(l_row.md_lat)
      ql_lng    = float(l_row.md_lng)
      ql_name   = l_row.md_name
      ql_source = l_row.md_mysource
      ql_phone  = l_row.md_phone
         #
      l_marker = { "lat" : ql_lat, "lng" : ql_lng,
         "name" : ql_name, "source" : ql_source,
         "phone" : ql_phone }
      l_markers.append(l_marker)
         #
   print "Rows found: " + str(l_cntr)
   print ""
   
   return jsonify(l_markers)


      ###############################################


#
#  Run the second query screen, TAB 2.
#
#  Same basic play as the query from TAB 1.
#
@m_app.route('/_do_geoQuery2')
def do_geoQuery2():
   global m_session

   #
   #  Parameters sent from client to server.
   #
   l_lat1   = request.args.get('h_lat1' )
   l_lng1   = request.args.get('h_lng1' )
   l_lat2   = request.args.get('h_lat2' )
   l_lng2   = request.args.get('h_lng2' )
   l_lat3   = request.args.get('h_lat3' )
   l_lng3   = request.args.get('h_lng3' )
   l_lat4   = request.args.get('h_lat4' )
   l_lng4   = request.args.get('h_lng4' )

   #
   #  Variable we send back to the client; points on the map.
   #
   l_markers = []
      
   #
   #  Building the query string.
   #
   l_stmt =                                                    \
      "SELECT md_lat, md_lng, md_name, md_mysource,        " + \
      "md_phone                                            " + \
      "FROM ks_16.my_mapdata                               " + \
      "WHERE solr_query =                                  " + \
      "'{ \"q\" : \"*:*\", \"fq\" :                        " + \
      "\"{!field f=md_latlng}Intersects(POLYGON((          " + \
      l_lng1 + " " + l_lat1 + ", "                           + \
      l_lng2 + " " + l_lat2 + ", "                           + \
      l_lng3 + " " + l_lat3 + ", "                           + \
      l_lng4 + " " + l_lat4 + ", "                           + \
      l_lng1 + " " + l_lat1 +                                  \
      ")))\" }' LIMIT 1000;                                "
      
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Query2: " + l_stmt2

   l_rows = m_session.execute(l_stmt)
   l_cntr = 0
      
   #
   #  Fetch loop, build a return variable to the client.
   #
   for l_row in l_rows:
      l_cntr += 1 
         #
      ql_lat    = float(l_row.md_lat)
      ql_lng    = float(l_row.md_lng)
      ql_name   = l_row.md_name
      ql_source = l_row.md_mysource
      ql_phone  = l_row.md_phone
         #
      l_marker = { "lat" : ql_lat, "lng" : ql_lng,
         "name" : ql_name, "source" : ql_source,
         "phone" : ql_phone }
      l_markers.append(l_marker)
         #
   print "Rows found: " + str(l_cntr)
   print ""
   
   return jsonify(l_markers)


      ###############################################


#
#  Add a new point to the database, TAB 3.
#
#  (TAB 4 is handled entirely on the client.)
#
@m_app.route('/_do_C2S_addMarker')
def do_C2S_addMarker():
   global m_session

   l_lat    = request.args.get('h_lat' )
   l_lng    = request.args.get('h_lng' )
   l_name   = request.args.get('h_name')
      #
   l_pk     = str(uuid.uuid4())
   l_phone  = "303/808-2225"
   l_latlng = l_lat + ", " + l_lng
   l_source = "D"

   l_markers = []

   l_stmt =                                                    \
      "INSERT INTO ks_16.my_mapdata                        " + \
      "(md_pk, md_name, md_lat, md_lng, md_latlng,         " + \
      "md_phone, md_mysource)                              " + \
      " VALUES (%s, %s, %s, %s, %s, %s, %s );              "
         #
   m_session.execute(l_stmt, ( l_pk, l_name, l_lat,
      l_lng, l_latlng, l_phone, l_source ))
         #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Insert: " + l_stmt2
   print ""

   l_marker = { "lat" : l_lat, "lng" : l_lng,
      "name" : l_name, "source" : "D",
      "phone" : l_phone }
   l_markers.append(l_marker)

   return jsonify(l_markers)




#############################################################
#############################################################


#
#  And then running our Web site proper.
#
if __name__=='__main__':
   
   m_app.run(host = "localhost", port = int("8081"), debug=True)









