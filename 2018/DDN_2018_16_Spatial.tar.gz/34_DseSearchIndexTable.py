
#
#  Batch program to create DSE Search indexex ..
#

#
#  Assumptions below;
#
#  .  This program expects a functioning DSE at 127.0.0.1.
#
#  .  This program only needs DSE core and Search, nothing
#     more.
#

#
#  DSE driver installed via,
#     pip install dse-driver
#




############################################################
############################################################


#
#  Imports
#

from dse.cluster import Cluster

#
#  Used to sleep
#
import time
import sys

#
#  Hack to capture output from dsetool core_indexing_status ..
#
from subprocess import Popen, PIPE

#
#  String manipulation
#
import re


#
#  Variable that contains our database handle.
#
l_session = ""




############################################################
############################################################


#
#  Function to report on index build progress-
#
#     Index build progress is available via JMX, which we could
#     have done ain a Python program, but .. .. did this hack
#     instead.
#

#
#  subprocess, stderr stuff from,
#     https://www.saltycrane.com/blog/2008/09/how-get-stdout-and-stderr-using-python-subprocess-module/
#

#
#  Hack to capture output from dsetool core_indexing_status ..
#
#  Data looks like ..
#
#     Unknown core with name 'ks_16.my_mapdata'
#     [ks_16.my_mapdata]: INDEXING, N/A% complete, ETA N/A milliseconds (N/A)
#     [ks_16.my_mapdata]: INDEXING, 5% complete, ETA 173527 milliseconds (2 minutes 53 seconds)
#     [ks_16.my_mapdata]: INDEXING, 32% complete, ETA 98007 milliseconds (1 minute 38 seconds)
#     [ks_16.my_mapdata]: INDEXING, 60% complete, ETA 55348 milliseconds (55 seconds)
#     [ks_16.my_mapdata]: INDEXING, N/A% complete, ETA N/A milliseconds (N/A)
#     [ks_16.my_mapdata]: FINISHED
#


def watchIndexBuild():

   l_loopFlag = True
      #
   while l_loopFlag:

      l_cmd      = "dsetool core_indexing_status ks_16.my_mapdata"
      l_ifStdout = 0
         #
      l_pipe = Popen(l_cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE, close_fds=True)  
         #
      for l_line in l_pipe.stdout:
         l_ifStdout = 1
            #
         l_lineAsTokens = re.split('[ ,()\n]', l_line)
            #
         if (  l_lineAsTokens[1] == "FINISHED"):
            print "   Index build time remaining (secs): FINISHED"
            print ""
               #
            l_loopFlag = False
         elif (l_lineAsTokens[1] == "INDEXING"):
            if (l_lineAsTokens[7] == "N/A"):
               print "   Index build time remaining (secs): UNKNOWN"
            else:
               l_secs = int(l_lineAsTokens[7]) / 1000
               print "   Index build time remaining (secs): " + str(l_secs)
         
      if (l_ifStdout == 1):
         pass
      else:
         #
         #  Comes back as stderr, and we don't check that-
         #
         #     Unknown core with name 'ks_16.my_mapdata'
         #
         print "   No DSE Search index in place, or being built."
         print ""
      time.sleep(2)




############################################################
############################################################


#
#  Index build 1, pk ..
#

def indexTable_1():
   global l_session

   print ""
   print ""
   print "Working .. Build DSE Search index on primary key"
   print ""
   print ""


   l_cluster = Cluster(
      contact_points=['127.0.0.1']
      )
   l_session = l_cluster.connect()
   
   
   l_stmt =                                                                      \
      "DROP SEARCH INDEX ON ks_16.my_mapData;                                 "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""
 

   l_stmt =                                                                      \
      "CREATE SEARCH INDEX ON ks_16.my_mapData                               " + \
      "WITH COLUMNS md_pk, * {excluded : true } ;                            "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   print ""
   print "Watching index build 1 of 3 (PK) .."
   print ""
   #
   #  Start a thread that watches index build
   #
   watchIndexBuild()
   print ""
   print ""




############################################################


#
#  Index build 2, other ..
#

def indexTable_2():
   global l_session

   print ""
   print ""
   print "Working .. Build DSE Search index for geo-spatial, including polygon"
   print ""
   print ""


   #
   #  This was the block I ran until I added polygon.
   #
   #  l_stmt =                                                                   \
   #     "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapData                      " + \
   #     "ADD types.fieldType[@name='ft_latlng',                             " + \
   #     "@class='solr.LatLonType', @subFieldSuffix='_coord'];               "
   l_stmt =                                                                      \
         "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapdata                      " + \
         "ADD types.fieldType[@name='ft_latlng',                             " + \
         "@class='solr.SpatialRecursivePrefixTreeFieldType',                 " + \
         "@spatialContextFactory=                                            " + \
         "'org.locationtech.spatial4j.context.jts.JtsSpatialContextFactory', " + \
         "@autoIndex='true', @validationRule='repairBuffer0',                " + \
         "@distErrPct='0.025', @maxDistErr='0.001',                          " + \
         "@distanceUnits='kilometers'];                                      "

   try:
      l_resu = l_session.execute(l_stmt)
   except:
      print ""
      print "Error:  An error here almost certainly means that the DSE Search "
      print "  libraries are not in place. Please check that."
      print ""
      print ""
      sys.exit()
      
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapData                         " + \
      "ADD types.fieldType[@name='ft_double',                                " + \
      "@class='solr.TrieDoubleField'];                                       "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapData                         " + \
      "ADD dynamicField[@name='*_coord', @type='ft_double',                  " + \
      "@indexed='true', @stored='false'];                                    "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   #
   #  This was the block I ran until I added polygon.
   #
   #  l_stmt =                                                                   \
   #     "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapData                      " + \
   #     "ADD fields.field[@name='md_latlng', @type='ft_latlng',             " + \
   #     "@indexed='true', @multiValued='false', @stored='true'];            "
   l_stmt =                                                                      \
      "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapdata                         " + \
      "ADD fields.field[@name='md_latlng', @type='ft_latlng',                " + \
      "@indexed='true', @multiValued='false', @stored='true',                " + \
      "@docValues='true'];                                                   "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "RELOAD  SEARCH INDEX ON ks_16.my_mapData;                             "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "REBUILD SEARCH INDEX ON ks_16.my_mapData;                             "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "COMMIT  SEARCH INDEX ON ks_16.my_mapData;                             "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""


   print ""
   print "Watching index build 2 of 3 (geo-spatial) .."
   print ""
   #
   #  Start a thread that watches index build
   #
   watchIndexBuild()
   print ""
   print ""




############################################################


#
#  Index build 3, Soundex ..
#

def indexTable_3():
   global l_session

   print ""
   print ""
   print "Working .. Build DSE Search index for sounds-like"
   print ""
   print ""


   l_stmt =                                                                      \
      "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapData                         " + \
      "ADD types.fieldType[@name='TextField61',                              " + \
      "@class='solr.TextField'] with                                         " + \
      " '{\"analyzer\":{\"tokenizer\":{\"class\":                            " + \
      "\"solr.StandardTokenizerFactory\"},\"filter\":                        " + \
      "{\"class\":\"solr.BeiderMorseFilterFactory\",                         " + \
      "\"nameType\":\"GENERIC\", \"ruleType\":\"APPROX\",                    " + \
      " \"concat\":\"true\", \"languageSet\":\"auto\"}}}';                   "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "ALTER SEARCH INDEX SCHEMA ON ks_16.my_mapData                         " + \
      "ADD fields.field[@name='md_name', @type='TextField61',                " + \
      "@indexed='true', @multiValued='false', @stored='true'];               "

   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""


   l_stmt =                                                                      \
      "RELOAD  SEARCH INDEX ON ks_16.my_mapData;                             "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "REBUILD SEARCH INDEX ON ks_16.my_mapData;                             "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""

   l_stmt =                                                                      \
      "COMMIT  SEARCH INDEX ON ks_16.my_mapData;                             "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""


   print ""
   print "Watching index build 3 of 3 (sounds-like) .."
   print ""
   #
   #  Start a thread that watches index build
   #
   watchIndexBuild()
   print ""
   print ""




############################################################
############################################################


#
#  The program main.
#

if __name__=='__main__':
   indexTable_1()
   indexTable_2()
   indexTable_3()









