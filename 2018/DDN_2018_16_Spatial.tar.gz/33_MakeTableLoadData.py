

#
#  Batch program to create db, table, and load data from 2 sources.
#
#     -  About 330,000 records from USA, Colorado and Utah.
#     -  About 6000 Starbucks across the USA
#

#
#  Assumptions below;
#
#  .  This program expects a functioning DSE at 127.0.0.1.
#
#  .  This program only needs DSE core and Search, nothing
#     more.
#

#
#  DSE driver installed via,
#     pip install dse-driver
#
#  geoJSON information from,
#     https://stackoverflow.com/questions/42753745/how-can-i-parse-geojson-with-python
#
#     pip install geojson  # Wound up not using this package.
#
#     While these were geoJSON files, I was receving too many
#     illegal JSON formatting errors. So, we process these
#     files line by line as ASCII text.
#


#
#  First dataset being processed arrives one record per line. Each
#  line looks like this (whitespace added for readability
#  here.)
#
#     {
#     "geometry":
#        {
#        "type": "Point",
#        "coordinates": [-106.130131, 38.834339]
#        },
#     "type": "Feature",
#     "id": "SG_5vB6Z4vz5BKmkYwFVmcBgf_38.834339_-106.130131@1294083659",
#     "properties":
#        {
#        "province": "CO",
#        "city": "Buena Vista",
#        "name": "Upper Arkansas Valley Real Est",
#        "tags":
#           [
#           "appraiser"
#           ],
#        "country": "US",
#        "classifiers":
#           [
#           {
#           "category": "Professional",
#           "type": "Services",
#           "subcategory": "Business Services"
#           }
#           ],
#        "phone": "+1 719 395 3273",
#        "href": "http://api.simplegeo.com/1.0/features/SG_5vB6Z4vz5BKmkYwFVmcBgf_38.834339_-106.130131@1294083659.json",
#        "address": "306 Gunnison Cir",
#        "owner": "simplegeo",
#        "postcode": "81211"
#        }
#     }
#
#  Second dataset looks like this,
#
#     -149.8935557,61.21759217,Starbucks - AK - Anchorage  00001,"601 West Street_601 West 5th Avenue_Anchorage, Alaska 99501_907-277-2477"
#
#




############################################################
############################################################


#
#  Imports
#

from dse.cluster import Cluster

import json


#
#  Generate a unique key value
#
import uuid


#
#  Variable that contains our database handle.
#
l_session = ""




############################################################
############################################################


#
#  Setting up the database, and create table.
#

def createTable():
   global l_session

   print ""
   print ""
   print "Working .. (load Colorado/Utah: 330,000 points, plus Starbucks USA: 6000 points)"
   print ""
   print ""


   l_cluster = Cluster(
      contact_points=['127.0.0.1']
      )
   l_session = l_cluster.connect()
   
   
   l_stmt =                                                           \
      "DROP KEYSPACE IF EXISTS ks_16;                             "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""
 

   l_stmt =                                                           \
      "CREATE KEYSPACE ks_16 WITH REPLICATION =                   " + \
      "{'class': 'SimpleStrategy',                                " + \
      "   'replication_factor': 1};                               "
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2
   print ""


   l_stmt =                                                           \
      "CREATE TABLE ks_16.my_mapData                              " + \
      "   (                                                       " + \
      "   md_pk              TEXT,                                " + \
      "   md_latLng          TEXT,                                " + \
      "   md_lat             TEXT,                                " + \
      "   md_lng             TEXT,                                " + \
      "   md_name            TEXT,                                " + \
      "   md_address         TEXT,                                " + \
      "   md_city            TEXT,                                " + \
      "   md_province        TEXT,                                " + \
      "   md_postcode        TEXT,                                " + \
      "   md_country         TEXT,                                " + \
      "   md_phone           TEXT,                                " + \
      "   md_category        TEXT,                                " + \
      "   md_subCategory     TEXT,                                " + \
      "   md_type            TEXT,                                " + \
      "   md_tags            TEXT,                                " + \
      "   md_mySource        TEXT,                                " + \
      "   PRIMARY KEY (md_pk)                                     " + \
      "   );                                                      "
         #
   l_resu = l_session.execute(l_stmt)
      #
   l_stmt2 = ' '.join(l_stmt.split())
   print l_stmt2




############################################################


#
#  Load the table; fetch loop on the ASCII text file.
#

def loadTable1():
   global l_session


   print ""
   print ""
   print "Inserting Colorado/Utah data .."
   print ""
      #
   l_cntr = 0
      #
   l_stmt =                                                           \
      "INSERT INTO ks_16.my_mapData                               " + \
      "   ( md_pk          , md_latLng      , md_lat      ,       " + \
      "     md_lng         , md_name        ,                     " + \
      "     md_address     , md_city        , md_province ,       " + \
      "     md_postcode    , md_country     , md_phone    ,       " + \
      "     md_category    , md_subCategory , md_type     ,       " + \
      "     md_tags        , md_mySource                  )       " + \
      "VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s,               " + \
      "   %s, %s, %s, %s, %s, %s, %s ) ;                          "


   l_cntr     = 0
   s_mySource = "I"       # I == initial load, W == Web program


   with open ("23_places_dump_COUT.geojson", "r") as l_file:
      for l_line in l_file:
            
         l_cntr += 1
            #
         if (l_cntr % 10000 == 0):
            print "  Rows loaded: " + str(l_cntr) + " (of 330,000)"

         #
         #  Our read method also reads the newline character
         #  from the input file. Remove that.
         #
         l_line = l_line.replace("\n", "")
            #
         l_lineAsJSON = json.loads(l_line)
            #
         s_pk             = l_lineAsJSON['id']
            #
         s_lng            = str(l_lineAsJSON['geometry']['coordinates'][0])
         s_lat            = str(l_lineAsJSON['geometry']['coordinates'][1])
            #
         s_latLng         = str(s_lat) + ", " + str(s_lng)
            #
         s_name           = l_lineAsJSON['properties']['name']
         s_address        = l_lineAsJSON['properties']['address']
         s_city           = l_lineAsJSON['properties']['city']
         s_province       = l_lineAsJSON['properties']['province']
            #
         try:
            s_postcode    = l_lineAsJSON['properties']['postcode']
         except:
            #
            #  In Colorado/Utah, some input line after 240,000 didn't
            #  have a postcode
            #
            s_postcode    = "-----"
               #
         s_country        = l_lineAsJSON['properties']['country']
            #
         try:
            s_phone       = l_lineAsJSON['properties']['phone']
         except:
            #
            #  In Colorado/Utah, some input line after 200,000 didn't
            #  have a phone
            #
            s_phone       = "414/555-1212"
               #
         try:
            s_category    = l_lineAsJSON['properties']['classifiers'][0]['category']
            s_subCategory = l_lineAsJSON['properties']['classifiers'][0]['subcategory']
            s_type        = l_lineAsJSON['properties']['classifiers'][0]['type']
         except:
            s_category    = "(none)"
            s_subCategory = "(none)"
            s_type        = "(none)"
               #
         try:
            s_tags        = str( l_lineAsJSON['properties']['tags'] )
         except:
            s_tags        = "(no tags)"

   
         l_session.execute(l_stmt, ( s_pk                               ,
            s_latLng      , s_lat         , s_lng                       ,
            s_name        , s_address     ,   s_city                    ,
            s_province    , s_postcode    , s_country   , s_phone       ,
            s_category    , s_subCategory , s_type      , s_tags        ,
            s_mySource                                                   )) 


   print ""
   print ""
   print "Rows loaded: " + str(l_cntr)
   print ""
   print ""
   



############################################################


#
#  Load the table; fetch loop on the ASCII text file.
#

def loadTable2():
   global l_session


   print ""
   print ""
   print "Inserting Starbucks/USA data .."
   print ""
      #
   l_cntr = 0
      #
   l_stmt =                                                           \
      "INSERT INTO ks_16.my_mapData                               " + \
      "   ( md_pk          , md_latLng      , md_lat      ,       " + \
      "     md_lng         , md_name        ,                     " + \
      "     md_address     , md_city        , md_province ,       " + \
      "     md_postcode    , md_country     , md_phone    ,       " + \
      "     md_category    , md_subCategory , md_type     ,       " + \
      "     md_tags        , md_mySource                  )       " + \
      "VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s,               " + \
      "   %s, %s, %s, %s, %s, %s, %s ) ;                          "


   l_cntr     = 0
   s_mySource = "I"       # I == initial load, W == Web program


   with open ("24_Starbucks_USA_6000_2012.csv", "r") as l_file:
      for l_line in l_file:
            
         l_cntr += 1

         #
         #  Our read method also reads the newline character
         #  from the input file. Remove that.
         #
         l_line = l_line.replace("\n", "")

         s_pk             = str(uuid.uuid4())
         s_name           = "Starbucks"
         s_country        = "USA"
            #
         s_category       = "Food"
         s_subCategory    = "Coffee and Pastries"
         s_type           = "Commercial"
         s_tags           = "N/A"


         #
         #  Full line (on average)
         #
         # -149.8935557,61.21759217,Starbucks - AK - Anchorage  00001,"601 West Street_601 West 5th Avenue_Anchorage, Alaska 99501_907-277-2477"

         l_lineA          = l_line.split(" ")
         l_lineB          = l_lineA[0]
         l_lineC          = l_lineB.split(",")
            #
         s_lng            = l_lineC[0]
         s_lat            = l_lineC[1]
            #
         s_latLng         = s_lat + ", " + s_lng


         l_lineF          = l_line.split("\"")
         l_lineG          = l_lineF[1]
         l_lineH          = l_lineG.split("_")
            #
         try:
            s_phone       = l_lineH[3]
         except:
            s_phone       = "414/555-1212"


         l_lineJ          = l_lineH[2]
         l_lineK          = l_lineJ.split(" ")
            #
         s_postcode       = l_lineK[2]
            #
         s_postcode       = s_postcode[0:5]
            #
         s_province       = l_lineK[1]
            #
         l_lineL          = l_lineK[0]
         l_lineM          = l_lineL.replace(",", " ")
         s_city           = l_lineM
            #
         s_address        = l_lineH[0]


         l_session.execute(l_stmt, ( s_pk                               ,
            s_latLng      , s_lat         , s_lng                       ,
            s_name        , s_address     ,   s_city                    ,
            s_province    , s_postcode    , s_country   , s_phone       ,
            s_category    , s_subCategory , s_type      , s_tags        ,
            s_mySource                                                   )) 


   print ""
   print ""
   print "Rows loaded: " + str(l_cntr)
   print ""
   print ""
   



############################################################
############################################################


#
#  The program main.
#

if __name__=='__main__':
   createTable()
   loadTable1()
   loadTable2()
      #
   l_session.shutdown()



